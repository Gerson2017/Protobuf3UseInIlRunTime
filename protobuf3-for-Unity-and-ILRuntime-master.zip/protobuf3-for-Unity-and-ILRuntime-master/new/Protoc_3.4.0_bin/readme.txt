﻿a, 双击GenAllC#.bat，会从目录下所有的.proto生成c#代码文件，并输出到OuputC#目录里.
b, 拖一个.proto文件到GenOneC#.bat上，会生成这个.proto所对应的c#代码文件，并输出到OuputC#目录。
 
